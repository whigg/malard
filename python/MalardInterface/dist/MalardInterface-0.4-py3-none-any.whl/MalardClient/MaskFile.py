#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 09:09:45 2019

@author: jon
"""

class MaskFile:
    def __init__(  )